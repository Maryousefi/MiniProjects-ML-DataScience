SELECT 
    t.terminalno, 
    SUBSTRING(t.trandate FROM 1 FOR 7) AS transaction_month, -- استخراج سال/ماه
    SUM(
        CASE 
            WHEN t.trantype = 'purchase' AND t.amount < 5000 THEN 25
            WHEN t.trantype = 'purchase' AND t.amount BETWEEN 5000 AND 25000 THEN t.amount * 0.01
            WHEN t.trantype = 'purchase' AND t.amount > 25000 THEN 260
            WHEN t.trantype = 'balance_inquiry' THEN 200
            WHEN t.trantype = 'charge_purchase' THEN 100
            ELSE 0
        END
    ) AS total_fee
FROM tb_transactions t
WHERE t.amount IS NOT NULL
GROUP BY t.terminalno, transaction_month
ORDER BY transaction_month, total_fee DESC;

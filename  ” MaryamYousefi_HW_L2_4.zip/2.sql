SELECT m.terminal_no, m.shopname
FROM tb_merchants m
LEFT JOIN (
    SELECT t.terminalno, SUM(t.amount) AS total_amount
    FROM tb_transactions t
    GROUP BY t.terminalno
) tx ON m.terminal_no = tx.terminalno
WHERE tx.terminalno IS NULL OR tx.total_amount = 0;

WITH avg_total AS (
    SELECT AVG(amount) AS overall_avg
    FROM tb_transactions
),
city_avg AS (
    SELECT m.cityname AS city, 
           COUNT(t.amount) AS transaction_count,
           AVG(t.amount) AS city_avg_amount
    FROM tb_transactions t
    JOIN tb_merchants m ON t.terminalno = m.terminal_no
    WHERE t.amount IS NOT NULL  -- Exclude NULL values
    GROUP BY m.cityname
)
SELECT city_avg.city, 
       city_avg.transaction_count, 
       city_avg.city_avg_amount
FROM city_avg, avg_total
WHERE city_avg.city_avg_amount > avg_total.overall_avg
ORDER BY city_avg.city_avg_amount DESC;

SELECT 
    m.terminal_no,
    COALESCE(COUNT(t.rrn), 0) AS total_transactions,
    COALESCE(SUM(CASE WHEN t.trantype = '00' THEN 1 ELSE 0 END), 0) AS purchase_transactions,
    COALESCE(SUM(CASE WHEN t.trantype = '31' THEN 1 ELSE 0 END), 0) AS balance_inquiry_transactions,
    COALESCE(SUM(CASE WHEN t.trantype = '50' THEN 1 ELSE 0 END), 0) AS charge_purchase_transactions,
    COALESCE(SUM(t.amount), 0) AS total_amount
FROM tb_merchants m
LEFT JOIN tb_transactions t 
    ON m.terminal_no = t.terminalno 
    AND t.trandate BETWEEN '1401/10/01' AND '1401/10/30'
GROUP BY m.terminal_no
ORDER BY total_transactions DESC;

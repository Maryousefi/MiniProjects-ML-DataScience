SELECT m.provincename, SUM(t.amount) AS total_amount
FROM tb_transactions t
JOIN tb_merchants m ON t.terminalno = m.terminal_no
WHERE m.provincename IN ('البرز', 'خوزستان') 
AND t.trandate BETWEEN '1401/11/01' AND '1401/11/30'
AND t.amount IS NOT NULL
GROUP BY m.provincename;

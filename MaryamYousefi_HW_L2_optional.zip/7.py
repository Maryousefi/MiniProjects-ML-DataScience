class Vehicle:
    def __init__(self, brand, model, year):
        self.brand = brand
        self.model = model
        self.year = year

    def info(self):
        return f"{self.brand} {self.model} ({self.year})"

    @property
    def age(self):
        from datetime import datetime
        return datetime.now().year - self.year 

# Example
car = Vehicle("Honda", "Civic", 2018)
print(car.info())  # Output: Honda Civic (2018)
print(f"Car Age: {car.age} years")  

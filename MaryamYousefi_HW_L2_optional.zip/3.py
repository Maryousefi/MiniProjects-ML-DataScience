def is_palindrome(s):
    cleaned_s = ''.join(s.lower().split()) 
    return cleaned_s == cleaned_s[::-1]  

# Example usage:
print(is_palindrome("radar"))  # Output: True
print(is_palindrome("hello"))  # Output: False
print(is_palindrome("A man a plan a canal Panama"))  # Output: True

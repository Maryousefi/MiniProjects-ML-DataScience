import random

def generate_unique_randoms(count, start, end):
    numbers = set()
    while len(numbers) < count:
        num = random.randint(start, end)
        numbers.add(num)
    return list(numbers)

# Example usage:
print(generate_unique_randoms(5, 1, 50))


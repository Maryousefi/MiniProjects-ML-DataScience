from collections import Counter

def process_log_text(log_text):
    levels = []
    for line in log_text.strip().split('\n'):
        if line.startswith("INFO:"):
            levels.append("INFO")
        elif line.startswith("WARNING:"):
            levels.append("WARNING")
        elif line.startswith("ERROR:"):
            levels.append("ERROR")
    return dict(Counter(levels))

# Example:
log_data = """INFO: Starting process
WARNING: Low memory
ERROR: Process failed
INFO: Process completed"""

summary = process_log_text(log_data)
print(summary)  # Output: {'INFO': 2, 'WARNING': 1, 'ERROR': 1}

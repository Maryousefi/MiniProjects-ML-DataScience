def validate_age_input(age):
    if not isinstance(age, int):
        raise TypeError("Age should be an integer.")
    if age <= 0:
        raise ValueError("Age should be greater than zero.")
    return True

# Example:
try:
    print(validate_age_input(30))   
    print(validate_age_input(-2))   
except (TypeError, ValueError) as error:
    print("Input Error:", error)

class Calculator:
    def __init__(self, num1, num2):
        self.num1 = num1
        self.num2 = num2

    def perform_operation(self, operation):
        if operation == "add":
            return self.num1 + self.num2
        elif operation == "subtract":
            return self.num1 - self.num2
        elif operation == "multiply":
            return self.num1 * self.num2
        elif operation == "divide":
            if self.num2 != 0:
                return self.num1 / self.num2
            else:
                return "Error! Division by zero."
        elif operation == "power":
            return self.num1 ** self.num2
        else:
            return "Invalid operation."

# مثال استفاده
calc = Calculator(5, 2)
print("جمع:", calc.perform_operation("add"))         # خروجی: 7
print("تفریق:", calc.perform_operation("subtract"))  # خروجی: 3
print("ضرب:", calc.perform_operation("multiply"))    # خروجی: 10
print("تقسیم:", calc.perform_operation("divide"))    # خروجی: 2.5
print("توان:", calc.perform_operation("power"))      # خروجی: 25
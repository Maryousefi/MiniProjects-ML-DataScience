def factorial(n):
    result = 1
    for i in range(2, n + 1):  # Loop from 2 to n
        result *= i  
    return result

# Example
print(factorial(5))  # Output: 120
print(factorial(6))  # Output: 720

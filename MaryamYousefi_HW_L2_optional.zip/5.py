from collections import defaultdict

def merge_dicts(dict1, dict2):
    merged_dict = defaultdict(int)  
    for d in (dict1, dict2):  
        for key, value in d.items():
            merged_dict[key] += value  
    return dict(merged_dict)  

# Example
dict1 = {'a': 100, 'b': 200}
dict2 = {'b': 300, 'c': 400}
print(merge_dicts(dict1, dict2))  # Output: {'a': 100, 'b': 500, 'c': 400}

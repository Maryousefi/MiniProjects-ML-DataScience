def square_dict(lst):
    return {str(num): str(num ** 2) for num in lst}

# Example 
input_list = [2, 4, 5]
output_dict = square_dict(input_list)
print(output_dict)  # Output: {'2': '4', '4': '16', '5': '25'}

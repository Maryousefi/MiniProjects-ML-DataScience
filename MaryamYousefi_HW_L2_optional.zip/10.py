def extract_dates(text):
    import re
    parts = text.split()
    dates = []
    for part in parts:
        cleaned = part.strip(",.")
        if re.fullmatch(r"\d{2}/\d{2}/\d{4}", cleaned):
            month, day, year = map(int, cleaned.split("/"))
            if 1 <= month <= 12 and 1 <= day <= 31:  
                dates.append(cleaned)
    return dates

# Example:
text = "Important dates: 01/15/2020, 03/22/2021 and not 13/40/9999."
print(extract_dates(text))  # Output: ['01/15/2020', '03/22/2021']

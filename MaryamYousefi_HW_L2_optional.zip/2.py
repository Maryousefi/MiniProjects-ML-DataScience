class DictToObject:
    def __init__(self, input_dict):
        for key, value in input_dict.items():
            setattr(self, key, value)

# Example usage:
data = {'name': 'Mary', 'age': 27, 'city': 'Miami'}
obj = DictToObject(data)

# Access attributes تکرار
print(obj.name)  # Output: Mary
print(obj.age)   # Output: 27
print(obj.city)  # Output: Miami

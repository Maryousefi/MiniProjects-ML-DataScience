from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

iris = sns.load_dataset("iris")
iris_X = iris[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']]
iris_y = iris['species']

pca = PCA(n_components=2)
D2_X = pca.fit_transform(iris_X)

print("Shape of D2_X:", D2_X.shape)

D2_df = pd.DataFrame(D2_X, columns=['Principal Component 1', 'Principal Component 2'])
D2_df['species'] = iris_y

plt.figure(figsize=(8, 6))
for species in D2_df['species'].unique():
    subset = D2_df[D2_df['species'] == species]
    plt.scatter(subset['Principal Component 1'],
                subset['Principal Component 2'],
                label=species)

plt.xlabel("1st Principal Component")
plt.ylabel("2nd Principal Component")
plt.title("PCA of Iris Dataset")
plt.legend(title="Species")
plt.grid(True)
plt.show()

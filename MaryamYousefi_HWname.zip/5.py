from sklearn.datasets import load_digits
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
import numpy as np

digits = load_digits()

X = digits.data
y = digits.target

knn = KNeighborsClassifier(n_neighbors=3)

scores = cross_val_score(knn, X, y, cv=5)
print("Cross-validation scores:", scores)


mean_score = np.mean(scores)
std_dev = np.std(scores)

print("Mean accuracy:", mean_score)
print("Standard deviation:", std_dev)

#سوال ۵
#انحراف استاندارد پایین مثلا نزدیک ۰.۰۱ به ما نشون میده که عملکرد مدل در تقسیم‌بندی‌های مختلف داده تقریباً پایدار و قابل اعتماده و
#  اگر انحراف استاندارد بالا بود، نشانه‌ای از ناپایداری عملکرد مدل در برابر تغییرات مجموعه آموزشی و آزمایش هستش. 

from sklearn.mixture import GaussianMixture
import pandas as pd
import seaborn as sns

iris = sns.load_dataset("iris")
iris_X = iris[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']]

gmm = GaussianMixture(n_components=3, random_state=0)
gmm.fit(iris_X)

cluster_labels = gmm.predict(iris_X)

iris_df = iris.copy()
iris_df['cluster'] = cluster_labels

print(iris_df.head())

contingency_table = pd.crosstab(iris_df['species'], iris_df['cluster'])
print(contingency_table)

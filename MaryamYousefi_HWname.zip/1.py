import seaborn as sns
import pandas as pd

#الف 
iris = sns.load_dataset("iris")

print(iris.head())


X = iris[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']].values
y = iris['species'].values

print("X shape:", X.shape)
print("X type:", type(X))
print("y shape:", y.shape)
print("y type:", type(y))

#ب
print("Number of samples:", X.shape[0])
print("Feature names:", list(iris.columns[:-1]))

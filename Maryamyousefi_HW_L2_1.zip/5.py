input_sentence = input("Enter your sentence:")

reversed_sentence = ' '.join(input_sentence.split()[::-1])

print("Your reversed sentence:", reversed_sentence)
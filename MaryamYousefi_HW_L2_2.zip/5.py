def is_prime(n):
    """Check if the number n is prime."""
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def main():
    with open('DS codes/part 2/numbers.txt', 'r') as input_file:
        numbers = input_file.readlines()

    numbers = [int(number.strip()) for number in numbers]

    prime_numbers = [number for number in numbers if is_prime(number)]

    with open('DS codes/part 2/prime_numbers.txt', 'w') as output_file:
        for prime in prime_numbers:
            output_file.write(f"{prime}\n")

if __name__ == "__main__":
    main()
from abc import ABC, abstractmethod
import pandas as pd

class Employee(ABC):
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary

    @abstractmethod
    def get_salary(self):
        pass

class Manager(Employee):
    def __init__(self, name, salary, bonus):
        super().__init__(name, salary)
        self.bonus = bonus

    def get_salary(self):
        return self.salary + self.bonus

class Intern(Employee):
    def __init__(self, name, salary):
        super().__init__(name, salary)

    def get_salary(self):
        return self.salary // 2

class Team:
    def __init__(self, manager):
        self.manager = manager
        self.interns = []

    def add_intern(self, intern):
        self.interns.append(intern)

    def get_name_of_interns(self):
        return [intern.name for intern in self.interns]

    def search_for_name(self, name):
        if self.manager.name == name:
            return f"Manager: {self.manager.name}, Salary: {self.manager.get_salary()}"
        for intern in self.interns:
            if intern.name == name:
                return f"Intern: {intern.name}, Salary: {intern.get_salary()}"
        return None

    def create_salary_table(self):
        data = {
            'Employee Name': [self.manager.name] + [intern.name for intern in self.interns],
            'Employee Type': ['Manager'] + ['Intern' for _ in self.interns],
            'Base Salary': [self.manager.salary] + [intern.salary for intern in self.interns],
            'Bonus': [self.manager.bonus if isinstance(self.manager, Manager) else 0] + [0 for _ in self.interns],
            'Total Salary': [self.manager.get_salary()] + [intern.get_salary() for intern in self.interns]
        }
        df = pd.DataFrame(data)
        print(df)

manager = Manager("John Doe", 100000, 20000)
intern1 = Intern("Jane Smith", 50000)
intern2 = Intern("Alice Johnson", 55000)

team = Team(manager)
team.add_intern(intern1)
team.add_intern(intern2)

print("Manager's Salary:", manager.get_salary())
print("Intern1's Salary:", intern1.get_salary())
print("Intern2's Salary:", intern2.get_salary())

print("Interns in the team:", team.get_name_of_interns())

name_to_search = "Jane Smith"
result = team.search_for_name(name_to_search)
if result:
    print(f"Found {name_to_search}: {result}")
else:
    print(f"{name_to_search} not found in the team.")

team.create_salary_table()
import matplotlib.pyplot as plt

class Student:
    def __init__(self, name, grades):
        self.name = name
        self.grades = grades

    def average_grade(self):
        if not self.grades:
            return 0
        return sum(self.grades) / len(self.grades)

    def grade_category(self):
        average = self.average_grade()
        if average < 12:
            return "F"
        elif 12 <= average < 15:
            return "C"
        elif 15 <= average < 18:
            return "B"
        elif 18 <= average <= 20:
            return "A"
        else:
            return "Invalid average"

students = [
    Student("John Doe", [14, 16, 18, 19]),
    Student("Hannah Smith", [10, 12, 18, 15]),
    Student("Alice Griffin", [18, 19, 20, 17]),
    Student("Bob Williams", [10, 13, 12, 10])
]

names = []
averages = []
categories = []

for student in students:
    names.append(student.name)
    averages.append(student.average_grade())
    categories.append(student.grade_category())


plt.figure(figsize=(10, 6))
plt.bar(names, averages, color=['red' if cat == "F" else 'orange' if cat == "C" else 'green' if cat == "B" else 'blue' for cat in categories])
plt.title("Average Grades of Students")
plt.xlabel("Students")
plt.ylabel("Average Grades")
plt.ylim(0, 20)
plt.show()
import re
from collections import Counter

def process_text_file():
    with open('DS codes/part 2/input.txt', 'r', encoding='utf-8') as file:
        text = file.read()

    words = re.findall(r'\b\w+\b', text.lower())

    word_counts = Counter(words)

    with open('DS codes/part 2/word_counts.txt', 'w', encoding='utf-8') as output_file:
        for word, count in sorted(word_counts.items()):
            output_file.write(f"{word} {count}\n")

process_text_file()

def search_word():
    word_to_search = input("Enter a word to search: ").strip().lower()

    try:
        with open('DS codes/part 2/word_counts.txt', 'r', encoding='utf-8') as file:
            for line in file:
                if not line.strip():
                    continue
                try:
                    word, count = line.split()
                    if word == word_to_search:
                        print(f"The word '{word_to_search}' appears {count} times.")
                        return
                except ValueError:
                    continue
        print("Word not found.")
    except FileNotFoundError:
        print("The file 'DS codes/part 2/word_counts.txt' does not exist. Please run the text processing first.")

search_word()

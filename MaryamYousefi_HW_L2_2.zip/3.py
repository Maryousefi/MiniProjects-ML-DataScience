import re

class InvalidEmailError(Exception):
    pass

class InvalidPhoneNumberError(Exception):
    pass

class Customer:
    def __init__(self, name, email, phone_number):
        self.name = name
        if not self.is_valid_email(email):
            raise InvalidEmailError(f"Invalid email: {email}")
        self.email = email
        if not self.is_valid_phone(phone_number):
            raise InvalidPhoneNumberError(f"Invalid phone number: {phone_number}")
        self.phone_number = phone_number

    def is_valid_email(self, email):
        email_regex = r'^[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,}$'
        return re.match(email_regex, email) is not None

    def is_valid_phone(self, phone_number):
        phone_regex = r'^\+?[0-9]{10,}$'
        return re.match(phone_regex, phone_number) is not None

try:
    customer = Customer("John Doe", "john.doe@email.com", "+1234123412")
    print(customer.name)
    print(customer.email)
    print(customer.phone_number)
except InvalidEmailError as e:
    print(e)
except InvalidPhoneNumberError as e:
    print(e)
SELECT * 
FROM tb_transactions 
WHERE amount > 0 
AND trandate BETWEEN '2023-02-20' AND '2023-03-20'
AND terminalno IN (
    SELECT terminalno 
    FROM tb_merchants 
    WHERE provincename = 'آذربایجان شرقی'
) 
ORDER BY amount ASC 
LIMIT 5;

SELECT shopname, provincename, cityname, terminal_no
FROM tb_merchants
WHERE workflowcaption = 'تکمیل مدارک';

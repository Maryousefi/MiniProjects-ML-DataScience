SELECT * 
FROM tb_transactions 
WHERE terminalno IN (
    SELECT DISTINCT terminalno 
    FROM tb_transactions 
    WHERE amount > 200000 
    AND trandate BETWEEN '2022-12-22' AND '2023-01-20'
) 
AND trandate BETWEEN '2023-01-21' AND '2023-02-19';

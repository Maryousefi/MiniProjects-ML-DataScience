SELECT DATE(trandate) AS transaction_day, 
       terminalno, 
       COUNT(*) AS transaction_count, 
       MAX(amount) AS max_transaction_amount
FROM tb_transactions
GROUP BY transaction_day, terminalno
ORDER BY transaction_day ASC, terminalno;

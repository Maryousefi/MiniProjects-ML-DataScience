SELECT terminalno, 
       SUM(amount) AS total_amount
FROM tb_transactions
WHERE trandate BETWEEN '2023-02-20' AND '2023-03-20'
AND terminalno NOT IN (
    SELECT DISTINCT terminalno 
    FROM tb_transactions 
    WHERE trandate BETWEEN '2023-01-21' AND '2023-02-19'
)
GROUP BY terminalno
ORDER BY total_amount ASC;

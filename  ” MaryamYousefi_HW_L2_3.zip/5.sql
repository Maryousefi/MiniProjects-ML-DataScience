SELECT terminalno, 
       COUNT(*) AS transaction_count, 
       SUM(amount) AS total_amount
FROM tb_transactions
WHERE trandate BETWEEN '2023-01-21' AND '2023-02-19'
GROUP BY terminalno
ORDER BY total_amount DESC;

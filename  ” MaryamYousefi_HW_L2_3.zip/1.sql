SELECT * 
FROM tb_transactions 
WHERE amount > 100000
AND trandate BETWEEN '2023-01-15' AND '2023-02-13'
AND amount IS NOT NULL;
